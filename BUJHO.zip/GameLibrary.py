#بسم اللہ الرحمن الرحیم

#LibraryImports:

import random
import time
import os

#GameFunctions:
def LiveUserMainMenu():
    while(True):
        ClearConsole()
        MainMenuChoice = input("Please make a selection:\n1)LogIn\n2)Play as a guest\n3)Create a new account\n4)Delete an account\n5)ScoreBoard\n6)About\n7)Exit\n=====> ")
        if MainMenuChoice == "1":
            LogIn()

        elif MainMenuChoice == "2":
            ClearConsole()
            print("WARNING! Best scores of Guest playes are not recorded...")
            choice = input("Press Enter to continue or enter \"*\" without quotes to go back...\n=====> ")
            if choice == "*":
                continue
            else:
                ClearConsole()
                print(f"You are Guest{str(random.randint(111111, 999999))}\n")
                time.sleep(2)
                while(True):
                    GuestChoice = input("1)Play Game\n2)Leave Game\n=====> ")
                    ClearConsole()
                    if GuestChoice == "1":
                        GameBody()
                        continue
                    elif GuestChoice == "2":
                        break
                    else:
                        print("please enter a valid value...")
                        time.sleep(2)
                        continue 

        elif MainMenuChoice == "3":
            NewAccount()


        elif MainMenuChoice == "4":
            DeleteAccount()
            return 0

        elif MainMenuChoice == "5":
            ScoreBoard()

        elif MainMenuChoice == "6":
            while(True):
                ClearConsole()
                print("Developed By======================> Pirzada Shayan Ahmed Kazmi")
                print("Developed Using===================> Python Language")
                print("Version===========================> BUJHO-1.1")
                print("For errors/glitches report at=====> @shayankazmi99 (INSTAGRAM)")
                print("\nPlease make a selection:\n1)Visit Developer\n2)Back")
                AboutMenuChoice = input("=====> ")

                if AboutMenuChoice == "1":
                    os.system("start https://www.instagram.com/shayankazmi99")
                    continue

                elif AboutMenuChoice == "2":
                    return 0
                                
                else:
                    print("please enter a valid value...")
                    time.sleep(2)
                    continue

        elif MainMenuChoice == "7":
            while(True):
                ClearConsole()
                MainMenuExitChoice = input("Are You Sure?\n(y/n)=====> ")
                if MainMenuExitChoice == "Y" or MainMenuExitChoice == "y":
                    ClearConsole()
                    print("\n\n\n\n\t\t\t\tAllah_Hafiz")
                    time.sleep(2)
                    exit()
                elif MainMenuExitChoice == "N" or MainMenuExitChoice == "n":
                    break
                else:
                    print("Enter a valid value (y/n)...")
                    time.sleep(2)
        else:
            ClearConsole()
            print("Enter a valid value...")
            time.sleep(2)
#یہاں پر لاگڈ ان مین مینیو کا اختتام ہوتا ہے

def NoLiveUserMainMenu():
    while(True):
        ClearConsole()
        MainMenuChoice = input("Please make a selection:\n1)Play as a guest\n2)Create a new account\n3)About\n4)Exit\n=====> ")

        if MainMenuChoice == "1":
            ClearConsole()
            print("WARNING! Best scores of Guest playes are not recorded...")
            choice = input("Press Enter to continue or enter \"*\" without quotes to go back...\n=====> ")
            if choice == "*":
                continue
            else:

                while(True):
                    ClearConsole()
                    print(f"You are Guest{str(random.randint(111111, 999999))}\n")
                    time.sleep(2)
                    GuestChoice = input("1)Play Game\n2)Leave Game\n=====> ")
                    if GuestChoice == "1":
                        GameBody()
                        continue
                    elif GuestChoice == "2":
                        break
                    else:
                        print("please enter a valid value...")
                        time.sleep(2)
                        continue 

        elif MainMenuChoice == "2":
            NewAccount()

        elif MainMenuChoice == "3":
            while(True):
                ClearConsole()
                print("Developed By======================> Pirzada Shayan Ahmed Kazmi")
                print("Developed Using===================> Python Language")
                print("Version===========================> BUJHO-1.1")
                print("For errors/glitches report at=====> @shayankazmi99 (INSTAGRAM)")
                print("\nPlease make a selection:\n1)Visit Developer\n2)Back")
                AboutMenuChoice = input("=====> ")

                if AboutMenuChoice == "1":
                    os.system("start https://www.instagram.com/shayankazmi99")
                    continue

                elif AboutMenuChoice == "2":
                    return 0

                else:
                    print("please enter a valid value...")
                    time.sleep(2)
                    continue

        elif MainMenuChoice == "4":
            while(True):
                ClearConsole()
                MainMenuExitChoice = input("Are You Sure?\n(y/n)=====> ")
                if MainMenuExitChoice == "Y" or MainMenuExitChoice == "y":
                    ClearConsole()
                    print("\n\n\n\n\t\t\t\tAllah_Hafiz")
                    time.sleep(2)
                    exit()
                elif MainMenuExitChoice == "N" or MainMenuExitChoice == "n":
                    break
                else:
                    print("Enter a valid value (y/n)...")
                    time.sleep(2)
        
        else:
            ClearConsole()
            print("Enter a valid value...")
            time.sleep(2)
        
        return 0

def LoggedInMenu(LoggedUser):
    while(True):
        ClearConsole()
        LogInMenuSelection = input("Please Make a selection\n1)Play Game\n2)Log Out\n=====> ")
        
        if LogInMenuSelection == "1":
            StatsFromGameBody = GameBody()
            PlayerScore = int(StatsFromGameBody[2:])
            dLevel = StatsFromGameBody[0]
            if PlayerScore == 0:
                continue
            PlayerScoreFileHandle = open(f"Resources\\{LoggedUser}\\S{dLevel}.inf", "r")
            PlayerScoreContent = PlayerScoreFileHandle.read()
            PlayerScoreFileHandle.close()

            if PlayerScoreContent == "":
                PlayerScoreFileHandle = open(f"Resources\\{LoggedUser}\\S{dLevel}.inf", "w")
                PlayerScoreFileHandle.write(str(PlayerScore))
                PlayerScoreFileHandle.close()
            else:
                if int(PlayerScoreContent) < PlayerScore:
                    input("Press Enter to continue...")
                    continue
                elif int(PlayerScoreContent) == PlayerScore:
                    input("Press Enter to continue...")
                    continue
                else:
                    PlayerScoreFileHandle = open(f"Resources\\{LoggedUser}\\S{dLevel}.inf", "w")
                    PlayerScoreFileHandle.write(str(PlayerScore))
                    PlayerScoreFileHandle.close()

        elif LogInMenuSelection == "2":
            print("Logging out...")
            time.sleep(2)
            return 0
        else:
            print("Please enter a valid value...")
            time.sleep(2)
            ClearConsole()
            continue
        continue
#یہان پر لاگڈ ان مینیو کا اختتام ہوتا ہے

def DeleteAccount():
    ClearConsole()
    LiveAccounts = os.listdir("Resources\\")

    AccountToDelete = input("Enter the Username of the account which you want to delete or, enter \"*\" without quotes to go back\n=====> ")

    BoolVar = False

    for EachAccount in LiveAccounts:
        if AccountToDelete == EachAccount:
            BoolVar = True
            break
        else:
            continue

    if BoolVar == True:
        ClearConsole()
        PasswordInput = input(f"Enter the password for the account \"{AccountToDelete}\" to delete it\n=====> ")
        PasswordFileHandle = open(f"Resources\\{AccountToDelete}\p.inf", "r")
        RealPassword = PasswordFileHandle.read()
        PasswordFileHandle.close()
        if PasswordInput == RealPassword:
            while(True):
                ClearConsole()
                print(f"Do you really want to delete the account \"{AccountToDelete}\"? (You can not UNDO an account deletion)")
                QueryInput = input("(y/n)=====> ")
                if QueryInput == "y" or QueryInput == "Y":
                    ClearConsole()
                    os.system(f"rmdir /s /q Resources\\{AccountToDelete}")
                    LiveAccountCounterHandle = open("Resources\\TotalLiveAccounts.inf", "r")
                    TotalAccountsThen = int(LiveAccountCounterHandle.read())
                    TotalAccountsNow  = TotalAccountsThen-1
                    LiveAccountCounterHandle.close()
                    LiveAccountCounterHandle = open("Resources\\TotalLiveAccounts.inf", "w")
                    LiveAccountCounterHandle.write(str(TotalAccountsNow))
                    LiveAccountCounterHandle.close()
                    print(f"The Account \"{AccountToDelete}\" has been deleted succesfully...")
                    time.sleep(2)
                    return
                elif QueryInput == "N" or QueryInput == "n":
                    ClearConsole()
                    print("Account Deletion Aborted...")
                    time.sleep(2)
                    return
                else:
                    ClearConsole()
                    print("Please Enter a Valid Value...")
                    time.sleep(2)
                    continue
        else:
            ClearConsole()
            print("YOU HAVE ENTERED THE WRONG PASSWORD!!!")
            time.sleep(2)
            return
    else:
        ClearConsole()
        print(f"There is no Account named \"{AccountToDelete}\"")
        time.sleep(2)
        return

#Yahan per DeleteAccount ka ikhtetam hota hai

def DifficultyLevelSelector():
    ClearConsole()
    print("Please Enter a difficulty level")
    print("1)Easy=====>(0 to 100)\n2)Medium===>(0 to 1K)\n3)Hard=====>(0 to 10K)\n4)Back")
    DifficultyInput = input("=====> ")
    return DifficultyInput
#یہاں پر ڈفی کلٹی لیول سیلکٹر کا اختتام ہوتا ہے 

def GameBody():
    while(True):
        ClearConsole()
        DifficultyLevel = DifficultyLevelSelector()
        if DifficultyLevel == "1":
            UnknownNumber = random.randint(0,100)
            ClearConsole()
            input("Difficulty level 1...\nPress Enter to continue...")
            break
        elif DifficultyLevel == "2":
            UnknownNumber = random.randint(0,1000)
            ClearConsole()
            input("Difficulty level 2...\nPress Enter to continue...")
            break
        elif DifficultyLevel == "3":
            UnknownNumber = random.randint(0,10000)
            ClearConsole()
            input("Difficulty level 3...\nPress Enter to continue...")
            break
        elif DifficultyLevel == "4":
            return 0
        else:
            input("Please Enter a valid value...\nPress Enter to continue...\n")
            ClearConsole()
            continue

    StepsTaken = 0
    while(True):
        ClearConsole()

        while(True):
            InputNumber = input("Guess the number: ")
            if DigitChecker(InputNumber) == True:
                break
            else:
                print("Please enter only a digit...")
                time.sleep(2)
                ClearConsole()
                continue

        if int(InputNumber) > UnknownNumber:
            print("The entered number is greater than the unknown number...")
            StepsTaken += 1
            time.sleep(2)
            continue
        elif int(InputNumber) < UnknownNumber:
            print("The entered number is smaller than the unknown number...")
            StepsTaken += 1
            time.sleep(2)
            continue
        else:
            StepsTaken += 1
            ClearConsole()
            print("Congratulations... You have guessed the number correctly...")
            print("The number was", UnknownNumber)
            if StepsTaken == 1:
                print("You took", StepsTaken , "step to guess the correct number!")
            else:
                print("You took", StepsTaken , "steps to guess the correct number!")
            input("Press Enter to continue...")
            ClearConsole()
        break
    ReturnStatement = f"{DifficultyLevel},{StepsTaken}"
    return ReturnStatement
#یہاں پر گیم باڈی کا اختتام ہوتا ہے


def MainMenu():
    ClearConsole()
    while(True):
        print("Please make a selection:\n1)LogIn\n2)Create a new account\n3)Play as a guest\n4)Exit")
        ProfileMenuInput = input("====> ")
        if ProfileMenuInput == "1":
            PlayerName = LogIn()
            #PlayerName = "TempPlayerName"
        elif ProfileMenuInput == "2":
            NewAccount()
            PlayerName = "TempPlayerName"
        elif ProfileMenuInput == "3":
            PlayerName = "Guest" + str(random.randint(111111, 999999))
            print("You are", PlayerName, "\nPress Enter to continue...", end="")
            input()

        elif ProfileMenuInput == "4":
            exit()
        else:
            input("Please make a valid selection\nPress Enter to continue...")
            ClearConsole()
            continue
        break
    return PlayerName
#یہاں پر پروفایل مینیجر کا اختتام ہوتا ہے

def DigitChecker(StringVar):
    ClearConsole()
    if StringVar.isdigit() == True:
        return True
    else:
        return False
#یہاں پر ڈجٹ چیکر کا اختتام ہوتا ہے

def LogIn():
    ClearConsole()
    UserName = input("Enter your Username or enter \"*\" without quotes to go back\nUsername=====> ")
    if UserName != "*":
        BoolVar = False
        LiveUsernames = os.listdir("Resources\\")
        for EachUsername in LiveUsernames:
            if UserName == EachUsername:
                BoolVar = True
                break
            else:
                continue

        if BoolVar == True:
            ClearConsole()
            PassWord = input("Enter your Password or enter \"*\" without quotes to go back\nPassword=====> ")
            if PassWord != "*":
                PasswordFileHandle = open(f"Resources\\{UserName}\\p.inf")
                OrignalPassword = PasswordFileHandle.read()
                if PassWord == OrignalPassword:
                    LoggedInMenu(UserName)
                else:
                    ClearConsole()
                    print("INCORRECT PASSWORD!!!")
                    time.sleep(2)
                    return
        else:
            ClearConsole()
            print("No Such Username available...")
            time.sleep(2)
            return
#یہاں پر لاگ ان اختتام پزیر ہوتا ہے

def NewAccount():
    while(True):
        ClearConsole()
        NewName = input("Enter a Username (No Special Characters)\nor type \"*\" without quotes to go back\n=====> ")
        if NewName == "*":
            return 0
        else:
            BoolVar = False
            LiveAccounts = os.listdir("Resources\\")

            for EachAccount in LiveAccounts:
                if NewName == EachAccount:
                    BoolVar = True
                    break
                else:
                    continue
            if BoolVar == True:
                ClearConsole()
                print(f"The username \"{NewName}\" has already been taken, please try another one...")
                time.sleep(2)
                return
            else:
                break

    ClearConsole()
    NewPass = input(f"Enter the Password For the Username \"{NewName}\" (No Special Characters)\nor type \"*\" without quotes to go back\n=====> ")

    if NewPass == "*":
        return 0
    else:
        os.system(f"md resources\\{NewName}")

        PaFileName    = f"Resources\\{NewName}\\P.inf"
        ScEasyFileName    = f"Resources\\{NewName}\\S1.inf"
        ScMediFileName    = f"Resources\\{NewName}\\S2.inf"
        ScHardFileName    = f"Resources\\{NewName}\\S3.inf"

        os.system(f"echo %date%>>Resources\\{NewName}\\date.inf")
        os.system(f"echo %time%>>Resources\\{NewName}\\time.inf")

        DateFileHandle = open(f"Resources\\{NewName}\\date.inf", "r")
        DateOfCreation = DateFileHandle.read()
        DateFileHandle.close()

        TimeFileHandle = open(f"Resources\\{NewName}\\time.inf", "r")
        TimeOfCreation = TimeFileHandle.read()
        TimeFileHandle.close()

        os.system(f"del Resources\\{NewName}\\date.inf")
        os.system(f"del Resources\\{NewName}\\time.inf")

        DB_HistoryLog = f"{DateOfCreation.strip()} || {TimeOfCreation.strip()} || {NewName}:{NewPass}\n"

        PaFileHandle = open(PaFileName, "w")
        PaFileHandle.write(NewPass)
        PaFileHandle.close()

        ScEasyHandle = open(ScEasyFileName, "w")
        ScEasyHandle.write("")
        ScEasyHandle.close()

        ScMediHandle = open(ScMediFileName, "w")
        ScMediHandle.write("")
        ScMediHandle.close()

        ScHardHandle = open(ScHardFileName, "w")
        ScHardHandle.write("")
        ScHardHandle.close()

        DB_HistoryUpdateHandle = open("Resources\\DataBaseHistory.inf", "a")
        DB_HistoryUpdateHandle.write(DB_HistoryLog)
        DB_HistoryUpdateHandle.close

        LiveCountFileHandle = open("Resources\\TotalLiveAccounts.inf", "r")
        TotalLiveAccounts = int(LiveCountFileHandle.read())
        LiveCountFileHandle.close()

        LiveCountFileHandle = open("Resources\\TotalLiveAccounts.inf", "w")
        LiveCountFileHandle.write(str(TotalLiveAccounts+1))
        LiveCountFileHandle.close()

        EverCountFileHandle = open("Resources\\TotalEverAccounts.inf", "r")
        TotalEverAccounts = int(EverCountFileHandle.read())
        EverCountFileHandle.close()

        EverCountFileHandle = open("Resources\\TotalEverAccounts.inf", "w")
        EverCountFileHandle.write(str(TotalEverAccounts+1))
        EverCountFileHandle.close()

        ClearConsole()
        input(f"New account has been created having the username \"{NewName}\"\n\n Press any key to continue...")
        ClearConsole()
        return 0
#یہاں پر نیو اکاونٹ اختتام پزیر ہوتا ہے


def ScoreBoard():
    while(True):
        ClearConsole()
        print("Please enter a score category\n1)Easy\n2)Medium\n3)Hard\n4)Back")
        ScoreCategory = input("=====> ")

        if ScoreCategory == "1":
            Users = os.listdir("Resources\\")
            ClearConsole()
            print("\t\t\t\t" + "*" * 29)
            print("\t\t\t\t*  Player Scores Easy Mode  *")
            print("\t\t\t\t" + "*" * 29)
            print("\t\t        USERNAME..............................SCORE\n")

            for EachUser in Users:
                if EachUser == "DataBaseHistory.inf" or EachUser == "TotalEverAccounts.inf" or EachUser == "TotalLiveAccounts.inf":
                    continue
                ScoreHandle = open(f"Resources\\{EachUser}\\S1.inf", "r")
                Score = ScoreHandle.read()
                ScoreHandle.close()
                print(f"\t\t        {EachUser}" + "." * int(38-len(EachUser)) + Score)
            input("\n\nPress Enter to continue...")

        elif ScoreCategory == "2":
            Users = os.listdir("Resources\\")
            ClearConsole()
            print("\t\t\t\t" + "*" * 31)
            print("\t\t\t\t*  Player Scores Medium Mode  *")
            print("\t\t\t\t" + "*" * 31)
            print("\t\t        USERNAME................................SCORE\n")

            for EachUser in Users:
                if EachUser == "DataBaseHistory.inf" or EachUser == "TotalEverAccounts.inf" or EachUser == "TotalLiveAccounts.inf":
                    continue
                ScoreHandle = open(f"Resources\\{EachUser}\\S2.inf", "r")
                Score = ScoreHandle.read()
                ScoreHandle.close()
                print(f"\t\t        {EachUser}" + "." * int(40-len(EachUser)) + Score)
            input("\n\nPress Enter to continue...")

        elif ScoreCategory == "3":
            Users = os.listdir("Resources\\")
            ClearConsole()
            print("\t\t\t\t" + "*" * 34)
            print("\t\t\t\t*  Player Scores Difficult Mode  *")
            print("\t\t\t\t" + "*" * 34)
            print("\t\t        USERNAME................................SCORE\n")

            for EachUser in Users:
                if EachUser == "DataBaseHistory.inf" or EachUser == "TotalEverAccounts.inf" or EachUser == "TotalLiveAccounts.inf":
                    continue
                ScoreHandle = open(f"Resources\\{EachUser}\\S3.inf", "r")
                Score = ScoreHandle.read()
                ScoreHandle.close()
                print(f"\t\t        {EachUser}" + "." * int(40-len(EachUser)) + Score)
            input("\n\nPress Enter to continue...")

        elif ScoreCategory == "4":
            return 0
    
        else:
            ClearConsole()
            input("Please make a valid selection\nPress Enter to continue...")
            continue
#یہاں پر اسکوربورڈ اختتام پزیر ہوتا ہے

            
#OtherFunctions:

def Intro():
    print("\t\t\t\tSHAYAN PRESENTS\n\t\t\t\t    ...")
    time.sleep(2)
    ClearConsole()
    print("                                               :.                                                         ") 
    print("                                               B#Y~.                                                       ")
    print("                                              J@@@@#57^.                                                  ")
    print("           .                    ^!77~.       !@@@@@@@@@#GY?!~^^^~!?^            .                         ")
    print("       ^JPB#BPJ~              ?B@@@@@G.     ^&@@@@@@@@@@@@@@@@@@@@@B        .75B##GY!.             !?YPBP ")
    print("     :P@@@@@@@@@B7          .P@@@@@@@@7     :JG&@@@@@@@@@@@@@@@@@@@B       J&@@@@@@@@&Y.           B@@@@@^")
    print("    ^#@@@@@@@@@@@@P.        P@@&&@@@@@^ .      .~?YG#&@@@@@@@@@&##&J      P@@@@@@@@@@@@#^          Y@@@@@^")
    print("    J@@@@@@@@@@@@@@Y       Y@@@5#@@@&7:5&P^         :J&@@@@&P?~:...      ^@@@@@@@@@@@@@@#.         G@@@@B ")
    print("    !@@@@@@@@@@@@@@@Y~::::J@@@@@@@@&??#@@@&?:...^!JP#@@@&G7.             .#@@@@@@@@@@@@@@P!:    .~P@@@@@! ")
    print("     7B@@@@@@@@@@@@@@@@&&&@@@@@@@@@@@@@@@@@@&##&@@@@@@B?:                 ^P&@@@@@@@@@@@@@@&BGBB&@@@@@@5  ")
    print("       ^!777?5@@@@@&@@@@@@@@@@@@@@@@@@@@@&&@@@@@@@@BJ^   .^!!:              :~7777J#@@@@@@@@@@@@@@@@@@J   ")
    print("          :?G@@@@@P:!J5PG&@@@@@@GP#@@@@@@#^7YPP5J!:     ?#@@@@7                .!P&@@@@#~~?5B&@@@@&BY^    ")
    print("     .^75B@@@@@@#?       :?B@@@@&PG@@@@@@@^             G@@@@@J            :~JG&@@@@@@5:     .^~^:.       ")
    print(" ~7YP#@@@@@@@@#?.           !P&@@@@@@@@@@G.             .?PBGJ.    ^^^~7J5B&@@@@@@@&5^      ~5GGP?:       ")
    print(".@@@@@@@@@@&5!.               :!Y5GGGGPY!                          ^Y#@@@@@@@@@@&G?:       ^@@@@@@B       ")
    print(" ?G&@@@&BY!.                                                         .!5#@@@&#57:          .G@@@@B!       ")
    print("   :~!^.                                                                .^!~:                ~77~         ")
    time.sleep(4)
#یہاں پر انٹرو اختتام پزیر ہوتا ہے

def ClearConsole():
    os.system('cls' if os.name == 'nt' else 'clear' )


#بسم اللہ الرحمن الرحیم

import GameLibrary
import os

os.system("color 0a")
os.system("title BUJHO By Shayan")

GameLibrary.Intro()

while(True):
    TotalLiveUsersFileHandle = open("Resources\\TotalLiveAccounts.inf", "r")
    TotalUsers = int(TotalLiveUsersFileHandle.read())
    TotalLiveUsersFileHandle.close()
    if TotalUsers == 0:

        GameLibrary.NoLiveUserMainMenu()
    else:

        GameLibrary.LiveUserMainMenu()